var searchData=
[
  ['sec_2ec_0',['sec.c',['../sec_8c.html',1,'']]],
  ['sec_5fset_5fcaps_1',['sec_set_caps',['../sec_8c.html#ab5d5aa8b3f0c3c78e70c01b65cdf8295',1,'sec.c']]],
  ['sec_5fset_5fseccomp_2',['sec_set_seccomp',['../sec_8c.html#af024c161c17f9e893a2ccd84ea6e1ab8',1,'sec.c']]]
];
