var searchData=
[
  ['uid_0',['uid',['../barco_8c.html#a778fa98e494a9b3bd3a1440c0bedc9fb',1,'barco.c']]],
  ['user_2ec_1',['user.c',['../user_8c.html',1,'']]],
  ['user_5fnamespace_5finit_2',['user_namespace_init',['../user_8c.html#a0269ed2b431dde4caf6af1bceeb5e124',1,'user.c']]],
  ['user_5fnamespace_5fprepare_5fmappings_3',['user_namespace_prepare_mappings',['../user_8c.html#a84429c153ec06ddac8c5fb335de3ac72',1,'user.c']]]
];
