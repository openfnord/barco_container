var searchData=
[
  ['value_0',['value',['../structcgroups__setting.html#a34790f9505cd4978981c8e92c13454b4',1,'cgroups_setting']]],
  ['version_1',['version',['../barco_8c.html#acedf697ae39909e338d4073afa7926c1',1,'barco.c']]],
  ['vrb_2',['vrb',['../barco_8c.html#a8d067d24899a9b4aea392249ac59fe13',1,'barco.c']]]
];
