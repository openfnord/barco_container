var searchData=
[
  ['pivot_5froot_0',['pivot_root',['../mount_8c.html#ad21def10d66a46a8755ef20054ea218c',1,'mount.c']]]
];
