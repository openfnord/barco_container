var searchData=
[
  ['uid_0',['uid',['../barco_8c.html#a778fa98e494a9b3bd3a1440c0bedc9fb',1,'barco.c']]]
];
