var searchData=
[
  ['user_5fnamespace_5finit_0',['user_namespace_init',['../user_8c.html#a0269ed2b431dde4caf6af1bceeb5e124',1,'user.c']]],
  ['user_5fnamespace_5fprepare_5fmappings_1',['user_namespace_prepare_mappings',['../user_8c.html#a84429c153ec06ddac8c5fb335de3ac72',1,'user.c']]]
];
