var mount_8c =
[
    [ "mount_set", "mount_8c.html#ae738a5bcb3c49506b7f1f4496f96cb5e", null ],
    [ "pivot_root", "mount_8c.html#ad21def10d66a46a8755ef20054ea218c", null ]
];