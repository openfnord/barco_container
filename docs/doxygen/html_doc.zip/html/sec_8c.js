var sec_8c =
[
    [ "sec_set_caps", "sec_8c.html#ab5d5aa8b3f0c3c78e70c01b65cdf8295", null ],
    [ "sec_set_seccomp", "sec_8c.html#af024c161c17f9e893a2ccd84ea6e1ab8", null ]
];