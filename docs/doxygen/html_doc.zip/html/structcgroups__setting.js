var structcgroups__setting =
[
    [ "name", "structcgroups__setting.html#a15199bb4cfda253fd473bf264c07bed3", null ],
    [ "value", "structcgroups__setting.html#a34790f9505cd4978981c8e92c13454b4", null ]
];